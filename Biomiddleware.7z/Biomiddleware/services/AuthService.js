/**
 * Authentication Service
 * Handles admin authentication, session management, and security
 */

const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');

class AuthService {
    constructor(databaseService, config) {
        this.dbService = databaseService;
        this.config = config;
        this.saltRounds = 12;
        this.sessions = new Map(); // In-memory session store
        
        // Session cleanup interval (every hour)
        setInterval(() => {
            this.cleanupExpiredSessions();
        }, 60 * 60 * 1000);
    }
    
    /**
     * Get database instance
     */
    get db() {
        return this.dbService.db;
    }

    /**
     * Initialize the authentication service
     */
    async init() {
        try {
            // Create admin users table
            await this.createAdminTable();
            
            // Create default admin if none exists
            await this.createDefaultAdmin();
            
            console.log('🔐 AuthService initialized');
        } catch (error) {
            console.error('❌ AuthService initialization failed:', error.message);
            throw error;
        }
    }

    /**
     * Create the admin users table
     */
    async createAdminTable() {
        const createTableSQL = `
            CREATE TABLE IF NOT EXISTS admin_users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                email TEXT UNIQUE,
                password_hash TEXT NOT NULL,
                full_name TEXT,
                role TEXT DEFAULT 'admin',
                is_active BOOLEAN DEFAULT 1,
                last_login DATETIME,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                password_changed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                login_attempts INTEGER DEFAULT 0,
                locked_until DATETIME,
                two_factor_secret TEXT,
                two_factor_enabled BOOLEAN DEFAULT 0
            );
            
            CREATE INDEX IF NOT EXISTS idx_admin_username ON admin_users(username);
            CREATE INDEX IF NOT EXISTS idx_admin_email ON admin_users(email);
        `;
        
        await this.db.exec(createTableSQL);
    }

    /**
     * Create default admin account if none exists
     */
    async createDefaultAdmin() {
        const existingAdmin = await this.db.get('SELECT id FROM admin_users LIMIT 1');
        
        if (!existingAdmin) {
            const defaultPassword = this.generateSecurePassword();
            const hashedPassword = await bcrypt.hash(defaultPassword, this.saltRounds);
            
            const adminData = {
                username: 'admin',
                email: 'admin@biomiddleware.local',
                password_hash: hashedPassword,
                full_name: 'System Administrator',
                role: 'super_admin',
                is_active: 1
            };
            
            const result = await this.db.run(`
                INSERT INTO admin_users (
                    username, email, password_hash, full_name, role, is_active
                ) VALUES (?, ?, ?, ?, ?, ?)
            `, [
                adminData.username,
                adminData.email,
                adminData.password_hash,
                adminData.full_name,
                adminData.role,
                adminData.is_active
            ]);
            
            console.log('🔑 Default admin account created:');
            console.log(`   Username: ${adminData.username}`);
            console.log(`   Password: ${defaultPassword}`);
            console.log(`   Email: ${adminData.email}`);
            console.log('');
            console.log('⚠️  IMPORTANT: Change the default password after first login!');
            console.log('💡 Access the admin panel at: http://localhost:5173/admin');
            
            return { ...adminData, password: defaultPassword };
        }
        
        return null;
    }

    /**
     * Generate a secure random password
     */
    generateSecurePassword(length = 16) {
        const charset = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*';
        let password = '';
        
        for (let i = 0; i < length; i++) {
            password += charset.charAt(Math.floor(Math.random() * charset.length));
        }
        
        return password;
    }

    /**
     * Authenticate admin user
     */
    async authenticate(username, password, rememberMe = false) {
        try {
            // Get user from database
            const user = await this.db.get(`
                SELECT * FROM admin_users 
                WHERE username = ? AND is_active = 1
            `, [username]);
            
            if (!user) {
                throw new Error('Invalid username or password');
            }
            
            // Check if account is locked
            if (user.locked_until && new Date(user.locked_until) > new Date()) {
                const lockTimeRemaining = Math.ceil((new Date(user.locked_until) - new Date()) / 60000);
                throw new Error(`Account locked. Try again in ${lockTimeRemaining} minutes.`);
            }
            
            // Verify password
            const isValidPassword = await bcrypt.compare(password, user.password_hash);
            
            if (!isValidPassword) {
                // Increment login attempts
                await this.incrementLoginAttempts(user.id);
                throw new Error('Invalid username or password');
            }
            
            // Reset login attempts on successful login
            await this.resetLoginAttempts(user.id);
            
            // Update last login
            await this.updateLastLogin(user.id);
            
            // Generate session
            const session = await this.createSession(user, rememberMe);
            
            // Remove sensitive data before returning
            const { password_hash, two_factor_secret, ...safeUser } = user;
            
            return {
                user: safeUser,
                session: session,
                token: session.token
            };
            
        } catch (error) {
            console.error('Authentication error:', error.message);
            throw error;
        }
    }

    /**
     * Create a new session
     */
    async createSession(user, rememberMe = false) {
        const sessionId = crypto.randomUUID();
        const token = jwt.sign(
            { 
                sessionId,
                userId: user.id,
                username: user.username,
                role: user.role,
                iat: Math.floor(Date.now() / 1000)
            },
            this.config.security.jwtSecret,
            { 
                expiresIn: rememberMe ? '30d' : this.config.security.jwtExpiresIn 
            }
        );
        
        const expiresAt = new Date();
        if (rememberMe) {
            expiresAt.setDate(expiresAt.getDate() + 30);
        } else {
            expiresAt.setHours(expiresAt.getHours() + 24);
        }
        
        const session = {
            id: sessionId,
            userId: user.id,
            username: user.username,
            role: user.role,
            token: token,
            createdAt: new Date(),
            expiresAt: expiresAt,
            lastActivity: new Date(),
            ipAddress: null, // Will be set by middleware
            userAgent: null  // Will be set by middleware
        };
        
        // Store session in memory
        this.sessions.set(sessionId, session);
        
        return session;
    }

    /**
     * Validate session token
     */
    async validateSession(token) {
        try {
            const decoded = jwt.verify(token, this.config.security.jwtSecret);
            const session = this.sessions.get(decoded.sessionId);
            
            if (!session || session.expiresAt < new Date()) {
                throw new Error('Session expired');
            }
            
            // Update last activity
            session.lastActivity = new Date();
            
            return session;
        } catch (error) {
            throw new Error('Invalid or expired session');
        }
    }

    /**
     * Logout user and destroy session
     */
    async logout(token) {
        try {
            const decoded = jwt.verify(token, this.config.security.jwtSecret);
            this.sessions.delete(decoded.sessionId);
            return true;
        } catch (error) {
            // Token might be invalid, but logout should still succeed
            return true;
        }
    }

    /**
     * Change user password
     */
    async changePassword(userId, currentPassword, newPassword) {
        const user = await this.db.get('SELECT * FROM admin_users WHERE id = ?', [userId]);
        
        if (!user) {
            throw new Error('User not found');
        }
        
        // Verify current password
        const isValidPassword = await bcrypt.compare(currentPassword, user.password_hash);
        if (!isValidPassword) {
            throw new Error('Current password is incorrect');
        }
        
        // Validate new password strength
        this.validatePasswordStrength(newPassword);
        
        // Hash new password
        const hashedPassword = await bcrypt.hash(newPassword, this.saltRounds);
        
        // Update password
        await this.db.run(`
            UPDATE admin_users 
            SET password_hash = ?, password_changed_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        `, [hashedPassword, userId]);
        
        // Invalidate all sessions for this user
        for (const [sessionId, session] of this.sessions.entries()) {
            if (session.userId === userId) {
                this.sessions.delete(sessionId);
            }
        }
        
        return true;
    }

    /**
     * Validate password strength
     */
    validatePasswordStrength(password) {
        if (password.length < 8) {
            throw new Error('Password must be at least 8 characters long');
        }
        
        if (!/(?=.*[a-z])/.test(password)) {
            throw new Error('Password must contain at least one lowercase letter');
        }
        
        if (!/(?=.*[A-Z])/.test(password)) {
            throw new Error('Password must contain at least one uppercase letter');
        }
        
        if (!/(?=.*\d)/.test(password)) {
            throw new Error('Password must contain at least one number');
        }
        
        if (!/(?=.*[@$!%*?&])/.test(password)) {
            throw new Error('Password must contain at least one special character (@$!%*?&)');
        }
        
        return true;
    }

    /**
     * Increment login attempts
     */
    async incrementLoginAttempts(userId) {
        const result = await this.db.run(`
            UPDATE admin_users 
            SET login_attempts = login_attempts + 1,
                locked_until = CASE 
                    WHEN login_attempts >= 4 THEN datetime('now', '+30 minutes')
                    ELSE locked_until
                END,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        `, [userId]);
        
        return result;
    }

    /**
     * Reset login attempts
     */
    async resetLoginAttempts(userId) {
        return await this.db.run(`
            UPDATE admin_users 
            SET login_attempts = 0, locked_until = NULL, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        `, [userId]);
    }

    /**
     * Update last login timestamp
     */
    async updateLastLogin(userId) {
        return await this.db.run(`
            UPDATE admin_users 
            SET last_login = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        `, [userId]);
    }

    /**
     * Get user profile
     */
    async getUserProfile(userId) {
        const user = await this.db.get(`
            SELECT id, username, email, full_name, role, is_active, 
                   last_login, created_at, password_changed_at
            FROM admin_users 
            WHERE id = ?
        `, [userId]);
        
        return user;
    }

    /**
     * Update user profile
     */
    async updateUserProfile(userId, updates) {
        const allowedFields = ['email', 'full_name'];
        const fields = [];
        const values = [];
        
        for (const [key, value] of Object.entries(updates)) {
            if (allowedFields.includes(key)) {
                fields.push(`${key} = ?`);
                values.push(value);
            }
        }
        
        if (fields.length === 0) {
            throw new Error('No valid fields to update');
        }
        
        values.push(userId);
        
        return await this.db.run(`
            UPDATE admin_users 
            SET ${fields.join(', ')}, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        `, values);
    }

    /**
     * Clean up expired sessions
     */
    cleanupExpiredSessions() {
        const now = new Date();
        let cleanedUp = 0;
        
        for (const [sessionId, session] of this.sessions.entries()) {
            if (session.expiresAt < now) {
                this.sessions.delete(sessionId);
                cleanedUp++;
            }
        }
        
        if (cleanedUp > 0) {
            console.log(`🧹 Cleaned up ${cleanedUp} expired sessions`);
        }
    }

    /**
     * Get active sessions count
     */
    getActiveSessionsCount() {
        return this.sessions.size;
    }

    /**
     * Get session statistics
     */
    getSessionStats() {
        const now = new Date();
        let activeSessions = 0;
        let expiredSessions = 0;
        
        for (const session of this.sessions.values()) {
            if (session.expiresAt > now) {
                activeSessions++;
            } else {
                expiredSessions++;
            }
        }
        
        return {
            total: this.sessions.size,
            active: activeSessions,
            expired: expiredSessions
        };
    }

    /**
     * Force logout all sessions for a user
     */
    forceLogoutUser(userId) {
        let loggedOut = 0;
        
        for (const [sessionId, session] of this.sessions.entries()) {
            if (session.userId === userId) {
                this.sessions.delete(sessionId);
                loggedOut++;
            }
        }
        
        return loggedOut;
    }
}

module.exports = AuthService;
