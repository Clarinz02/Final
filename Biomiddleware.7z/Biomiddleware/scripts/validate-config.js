#!/usr/bin/env node
/**
 * Configuration Validation Script
 * 
 * This script validates the current environment configuration
 * and reports any issues or recommendations
 */

const fs = require('fs');
const path = require('path');

// Load configuration
require('dotenv').config();
const { config, validateConfig, isDevelopment, isProduction, get } = require('../config/environment');

/**
 * Colors for console output
 */
const colors = {
    reset: '\x1b[0m',
    bright: '\x1b[1m',
    red: '\x1b[31m',
    green: '\x1b[32m',
    yellow: '\x1b[33m',
    blue: '\x1b[34m',
    cyan: '\x1b[36m'
};

/**
 * Console logging with colors
 */
function log(message, color = colors.reset) {
    console.log(`${color}${message}${colors.reset}`);
}

/**
 * Check if required directories exist
 */
function checkDirectories() {
    log('\n📁 Checking Directories:', colors.cyan);
    log('=' .repeat(40), colors.cyan);
    
    const requiredDirs = [
        { path: './data', description: 'Database directory' },
        { path: './data/backups', description: 'Database backups' },
        { path: config.hr.employeePhotoPath, description: 'Employee photos' },
        { path: config.backup.exportPath, description: 'Data exports' },
        { path: './logs', description: 'Application logs' }
    ];
    
    let allGood = true;
    
    requiredDirs.forEach(({ path: dirPath, description }) => {
        if (fs.existsSync(dirPath)) {
            log(`  ✅ ${description}: ${dirPath}`, colors.green);
        } else {
            log(`  ❌ ${description}: ${dirPath} (missing)`, colors.red);
            allGood = false;
        }
    });
    
    if (!allGood) {
        log('\n💡 Create missing directories with:', colors.yellow);
        log('   mkdir -p data/backups data/photos logs exports', colors.yellow);
    }
    
    return allGood;
}

/**
 * Check database configuration
 */
function checkDatabase() {
    log('\n🗄️  Database Configuration:', colors.cyan);
    log('=' .repeat(40), colors.cyan);
    
    const dbPath = config.database.path;
    const backupPath = config.database.backupPath;
    
    log(`  Database Path: ${dbPath}`);
    log(`  Backup Path: ${backupPath}`);
    log(`  Auto Backup: ${config.database.autoBackup ? '✅' : '❌'}`);
    log(`  Backup Interval: ${config.database.backupInterval}ms`);
    
    // Check if database file exists
    if (fs.existsSync(dbPath)) {
        const stats = fs.statSync(dbPath);
        log(`  Database Size: ${(stats.size / 1024 / 1024).toFixed(2)} MB`, colors.green);
    } else {
        log(`  Database Status: Will be created on first run`, colors.yellow);
    }
    
    // Check backup directory
    if (fs.existsSync(backupPath)) {
        const backupFiles = fs.readdirSync(backupPath).filter(f => f.endsWith('.db'));
        log(`  Backup Files: ${backupFiles.length}`, colors.green);
    }
}

/**
 * Check security configuration
 */
function checkSecurity() {
    log('\n🔐 Security Configuration:', colors.cyan);
    log('=' .repeat(40), colors.cyan);
    
    // JWT Secret check
    if (config.security.jwtSecret === 'default-jwt-secret-change-in-production') {
        log('  JWT Secret: ❌ Using default value - CHANGE THIS!', colors.red);
    } else if (config.security.jwtSecret.length < 32) {
        log('  JWT Secret: ⚠️  Too short (< 32 chars)', colors.yellow);
    } else {
        log('  JWT Secret: ✅ Configured', colors.green);
    }
    
    // CORS check
    if (isProduction() && config.cors.origin === '*') {
        log('  CORS Origin: ⚠️  Set to * in production', colors.yellow);
    } else {
        log(`  CORS Origin: ${config.cors.origin}`, colors.green);
    }
    
    // Rate limiting
    log(`  Rate Limiting: ${config.features.apiRateLimiting ? '✅ Enabled' : '❌ Disabled'}`);
    
    if (config.features.apiRateLimiting) {
        log(`    Window: ${config.security.rateLimitWindowMs}ms`);
        log(`    Max Requests: ${config.security.rateLimitMaxRequests}`);
    }
}

/**
 * Check network configuration
 */
function checkNetwork() {
    log('\n🌐 Network Configuration:', colors.cyan);
    log('=' .repeat(40), colors.cyan);
    
    log(`  Server Host: ${config.server.host}`);
    log(`  Server Port: ${config.server.port}`);
    log(`  Auto Discovery: ${config.device.autoDiscoveryEnabled ? '✅' : '❌'}`);
    
    if (config.device.autoDiscoveryEnabled) {
        log(`    Network: ${config.device.autoDiscoveryNetwork}`);
        log(`    Timeout: ${config.device.autoDiscoveryTimeout}ms`);
    }
    
    // Check for proxy settings
    if (config.network.httpProxy || config.network.httpsProxy) {
        log('  Proxy Settings:', colors.yellow);
        if (config.network.httpProxy) log(`    HTTP: ${config.network.httpProxy}`);
        if (config.network.httpsProxy) log(`    HTTPS: ${config.network.httpsProxy}`);
    }
}

/**
 * Check feature flags
 */
function checkFeatures() {
    log('\n🎛️  Feature Configuration:', colors.cyan);
    log('=' .repeat(40), colors.cyan);
    
    const enabledFeatures = Object.entries(config.features)
        .filter(([_, enabled]) => enabled)
        .map(([feature, _]) => feature);
        
    const disabledFeatures = Object.entries(config.features)
        .filter(([_, enabled]) => !enabled)
        .map(([feature, _]) => feature);
    
    if (enabledFeatures.length > 0) {
        log('  Enabled Features:');
        enabledFeatures.forEach(feature => {
            log(`    ✅ ${feature.replace(/([A-Z])/g, ' $1').toLowerCase()}`, colors.green);
        });
    }
    
    if (disabledFeatures.length > 0) {
        log('  Disabled Features:');
        disabledFeatures.forEach(feature => {
            log(`    ❌ ${feature.replace(/([A-Z])/g, ' $1').toLowerCase()}`, colors.red);
        });
    }
    
    // Check experimental features
    const experimentalEnabled = Object.entries(config.experimental)
        .filter(([_, enabled]) => enabled)
        .map(([feature, _]) => feature);
    
    if (experimentalEnabled.length > 0) {
        log('\n  Experimental Features:', colors.yellow);
        experimentalEnabled.forEach(feature => {
            log(`    🧪 ${feature.replace(/([A-Z])/g, ' $1').toLowerCase()}`, colors.yellow);
        });
    }
}

/**
 * Check integrations
 */
function checkIntegrations() {
    log('\n🔌 Integration Configuration:', colors.cyan);
    log('=' .repeat(40), colors.cyan);
    
    // Email integration
    if (config.integrations.email.enabled) {
        log('  Email Integration: ✅ Enabled', colors.green);
        log(`    SMTP Host: ${config.integrations.email.smtpHost}`);
        log(`    SMTP Port: ${config.integrations.email.smtpPort}`);
        log(`    From Address: ${config.integrations.email.fromAddress}`);
    } else {
        log('  Email Integration: ❌ Disabled');
    }
    
    // Cloud storage integration
    if (config.integrations.cloudStorage.enabled) {
        log('  Cloud Storage: ✅ Enabled', colors.green);
        log(`    Provider: ${config.integrations.cloudStorage.provider}`);
        log(`    Bucket: ${config.integrations.cloudStorage.bucket}`);
    } else {
        log('  Cloud Storage: ❌ Disabled');
    }
    
    // Webhooks
    if (config.integrations.webhooks.enabled) {
        log('  Webhooks: ✅ Enabled', colors.green);
        log(`    URL: ${config.integrations.webhooks.url}`);
        log(`    Events: ${config.integrations.webhooks.events.join(', ')}`);
    } else {
        log('  Webhooks: ❌ Disabled');
    }
}

/**
 * Performance recommendations
 */
function checkPerformance() {
    log('\n⚡ Performance Configuration:', colors.cyan);
    log('=' .repeat(40), colors.cyan);
    
    log(`  Max Memory: ${config.performance.maxMemoryUsage}`);
    log(`  Max Connections: ${config.performance.maxConcurrentConnections}`);
    log(`  Connection Timeout: ${config.performance.connectionTimeout}ms`);
    log(`  Max File Size: ${config.performance.maxFileSize}`);
    log(`  GC Interval: ${config.performance.gcInterval}ms`);
    
    // Performance recommendations
    const maxConn = config.performance.maxConcurrentConnections;
    if (maxConn > 500) {
        log('  ⚠️  High max connections - monitor memory usage', colors.yellow);
    } else if (maxConn < 50) {
        log('  💡 Low max connections - consider increasing for production', colors.yellow);
    }
}

/**
 * Environment-specific recommendations
 */
function environmentRecommendations() {
    log('\n💡 Environment Recommendations:', colors.cyan);
    log('=' .repeat(40), colors.cyan);
    
    if (isDevelopment()) {
        log('  Development Mode:', colors.yellow);
        log('    • Enable debug logging for troubleshooting');
        log('    • Use mock devices for testing');
        log('    • Consider enabling auto-reload');
        
        if (!config.development.verboseLogging) {
            log('    💡 Enable DEV_VERBOSE_LOGGING for detailed logs', colors.yellow);
        }
    }
    
    if (isProduction()) {
        log('  Production Mode:', colors.green);
        log('    • Ensure JWT secret is changed');
        log('    • Restrict CORS origins');
        log('    • Enable rate limiting');
        log('    • Configure log file rotation');
        log('    • Set up monitoring and alerts');
        
        const recommendations = [];
        
        if (config.security.jwtSecret === 'default-jwt-secret-change-in-production') {
            recommendations.push('Change JWT_SECRET');
        }
        
        if (config.cors.origin === '*') {
            recommendations.push('Restrict CORS_ORIGIN');
        }
        
        if (!config.features.apiRateLimiting) {
            recommendations.push('Enable API rate limiting');
        }
        
        if (!config.logging.fileEnabled) {
            recommendations.push('Enable file logging');
        }
        
        if (recommendations.length > 0) {
            log('\n    🔴 Critical recommendations:', colors.red);
            recommendations.forEach(rec => log(`      • ${rec}`, colors.red));
        }
    }
}

/**
 * Main validation function
 */
function validateConfiguration() {
    log('🔍 BIOMIDDLEWARE CONFIGURATION VALIDATION', colors.bright);
    log('=' .repeat(50), colors.bright);
    log(`Environment: ${config.server.nodeEnv.toUpperCase()}`, colors.bright);
    
    // Run validation from environment config
    const validation = validateConfig();
    
    if (!validation.isValid) {
        log('\n❌ Configuration Validation Errors:', colors.red);
        validation.errors.forEach(error => log(`  • ${error}`, colors.red));
    }
    
    if (validation.warnings.length > 0) {
        log('\n⚠️  Configuration Warnings:', colors.yellow);
        validation.warnings.forEach(warning => log(`  • ${warning}`, colors.yellow));
    }
    
    // Run detailed checks
    const directoriesOk = checkDirectories();
    checkDatabase();
    checkSecurity();
    checkNetwork();
    checkFeatures();
    checkIntegrations();
    checkPerformance();
    environmentRecommendations();
    
    // Final summary
    log('\n📊 Validation Summary:', colors.bright);
    log('=' .repeat(40), colors.bright);
    
    if (validation.isValid && directoriesOk) {
        log('✅ Configuration is valid and ready', colors.green);
    } else {
        log('❌ Configuration has issues that need attention', colors.red);
    }
    
    log(`\n🌐 Access your server at: http://${config.server.host}:${config.server.port}`, colors.cyan);
    
    return validation.isValid && directoriesOk;
}

/**
 * Show help information
 */
function showHelp() {
    console.log('BIOMIDDLEWARE Configuration Validator');
    console.log('=' .repeat(40));
    console.log('Usage: node scripts/validate-config.js [options]');
    console.log('');
    console.log('Options:');
    console.log('  --help, -h          Show this help message');
    console.log('  --json              Output results in JSON format');
    console.log('');
    console.log('This script validates your environment configuration');
    console.log('and provides recommendations for optimal setup.');
}

/**
 * Main function
 */
function main() {
    const args = process.argv.slice(2);
    
    // Check for help flag
    if (args.includes('--help') || args.includes('-h')) {
        showHelp();
        return;
    }
    
    try {
        const isValid = validateConfiguration();
        process.exit(isValid ? 0 : 1);
    } catch (error) {
        log(`❌ Validation failed: ${error.message}`, colors.red);
        process.exit(1);
    }
}

// Run if called directly
if (require.main === module) {
    main();
}

module.exports = {
    validateConfiguration,
    checkDirectories,
    checkDatabase,
    checkSecurity
};
