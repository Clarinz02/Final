#!/usr/bin/env node
/**
 * Environment Setup Script
 * 
 * This script helps set up the .env file for BIOMIDDLEWARE
 * by copying from .env.example and optionally prompting for values
 */

const fs = require('fs');
const path = require('path');
const readline = require('readline');
const crypto = require('crypto');

const PROJECT_ROOT = path.resolve(__dirname, '..');
const ENV_EXAMPLE_PATH = path.join(PROJECT_ROOT, '.env.example');
const ENV_PATH = path.join(PROJECT_ROOT, '.env');

/**
 * Generate a random JWT secret
 */
function generateJWTSecret() {
    return crypto.randomBytes(64).toString('hex');
}

/**
 * Generate a random API key
 */
function generateApiKey() {
    return crypto.randomBytes(32).toString('hex');
}

/**
 * Create readline interface
 */
function createReadline() {
    return readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });
}

/**
 * Prompt user for input
 */
function prompt(question, defaultValue = '') {
    const rl = createReadline();
    
    return new Promise((resolve) => {
        const displayDefault = defaultValue ? ` (${defaultValue})` : '';
        rl.question(`${question}${displayDefault}: `, (answer) => {
            rl.close();
            resolve(answer.trim() || defaultValue);
        });
    });
}

/**
 * Check if .env file already exists
 */
function checkExistingEnv() {
    return fs.existsSync(ENV_PATH);
}

/**
 * Copy .env.example to .env with optional modifications
 */
async function setupEnvironment(interactive = false) {
    console.log('🔧 Setting up BIOMIDDLEWARE environment...\n');

    // Check if .env already exists
    if (checkExistingEnv()) {
        console.log('⚠️  .env file already exists!');
        
        if (interactive) {
            const overwrite = await prompt('Do you want to overwrite it? (y/N)', 'N');
            if (overwrite.toLowerCase() !== 'y' && overwrite.toLowerCase() !== 'yes') {
                console.log('✅ Environment setup cancelled.');
                return;
            }
        } else {
            console.log('✅ Skipping setup to avoid overwriting existing configuration.');
            return;
        }
    }

    // Check if .env.example exists
    if (!fs.existsSync(ENV_EXAMPLE_PATH)) {
        console.error('❌ .env.example file not found!');
        console.error('   Please ensure you are running this script from the project root.');
        process.exit(1);
    }

    // Read .env.example
    let envContent = fs.readFileSync(ENV_EXAMPLE_PATH, 'utf8');

    if (interactive) {
        console.log('🔐 Security Configuration');
        console.log('=' .repeat(40));
        
        // Generate and ask for JWT secret
        const generatedJWTSecret = generateJWTSecret();
        const jwtSecret = await prompt('JWT Secret (leave empty to generate)', generatedJWTSecret);
        envContent = envContent.replace(
            'JWT_SECRET=default-jwt-secret-change-in-production',
            `JWT_SECRET=${jwtSecret}`
        );

        // Server configuration
        console.log('\n🌐 Server Configuration');
        console.log('=' .repeat(40));
        
        const port = await prompt('Server Port', '5173');
        envContent = envContent.replace('PORT=5173', `PORT=${port}`);
        
        const host = await prompt('Server Host', 'localhost');
        envContent = envContent.replace('HOST=localhost', `HOST=${host}`);

        // Database configuration
        console.log('\n🗄️  Database Configuration');
        console.log('=' .repeat(40));
        
        const dbPath = await prompt('Database Path', './data/biometric.db');
        envContent = envContent.replace('DB_PATH=./data/biometric.db', `DB_PATH=${dbPath}`);

        // Device configuration
        console.log('\n📱 Device Configuration');
        console.log('=' .repeat(40));
        
        const network = await prompt('Auto-discovery Network', '192.168.1.0/24');
        envContent = envContent.replace('AUTO_DISCOVERY_NETWORK=192.168.1.0/24', `AUTO_DISCOVERY_NETWORK=${network}`);

        // Environment
        console.log('\n⚙️  Environment Settings');
        console.log('=' .repeat(40));
        
        const nodeEnv = await prompt('Environment (development/production)', 'development');
        envContent = envContent.replace('NODE_ENV=development', `NODE_ENV=${nodeEnv}`);

        // Production-specific settings
        if (nodeEnv === 'production') {
            console.log('\n🔒 Production Security Settings');
            console.log('=' .repeat(40));
            
            const corsOrigin = await prompt('CORS Origin (domain or *)', '*');
            envContent = envContent.replace('CORS_ORIGIN=*', `CORS_ORIGIN=${corsOrigin}`);
            
            const logLevel = await prompt('Log Level (error/warn/info/debug)', 'warn');
            envContent = envContent.replace('LOG_LEVEL=info', `LOG_LEVEL=${logLevel}`);
        }
    } else {
        // Non-interactive mode - just replace sensitive defaults
        console.log('🔐 Generating secure defaults...');
        
        // Generate secure JWT secret
        const jwtSecret = generateJWTSecret();
        envContent = envContent.replace(
            'JWT_SECRET=default-jwt-secret-change-in-production',
            `JWT_SECRET=${jwtSecret}`
        );
        
        console.log('✅ Generated JWT secret');
    }

    // Write .env file
    try {
        fs.writeFileSync(ENV_PATH, envContent, 'utf8');
        console.log('\n✅ Environment file created successfully!');
        console.log(`📁 Location: ${ENV_PATH}`);
        
        // Show next steps
        console.log('\n📋 Next Steps:');
        console.log('  1. Review and customize your .env file');
        console.log('  2. Create necessary directories:');
        console.log('     - mkdir -p data/backups data/photos logs exports');
        console.log('  3. Start the server: npm start');
        console.log('  4. Access the web interface at the configured URL');
        
    } catch (error) {
        console.error('❌ Failed to write .env file:', error.message);
        process.exit(1);
    }
}

/**
 * Show help information
 */
function showHelp() {
    console.log('BIOMIDDLEWARE Environment Setup');
    console.log('=' .repeat(40));
    console.log('Usage: node scripts/setup-env.js [options]');
    console.log('');
    console.log('Options:');
    console.log('  --interactive, -i    Interactive setup with prompts');
    console.log('  --help, -h          Show this help message');
    console.log('');
    console.log('Examples:');
    console.log('  node scripts/setup-env.js              # Quick setup with secure defaults');
    console.log('  node scripts/setup-env.js --interactive # Interactive setup with prompts');
}

/**
 * Main function
 */
async function main() {
    const args = process.argv.slice(2);
    
    // Check for help flag
    if (args.includes('--help') || args.includes('-h')) {
        showHelp();
        return;
    }
    
    // Check for interactive flag
    const interactive = args.includes('--interactive') || args.includes('-i');
    
    try {
        await setupEnvironment(interactive);
    } catch (error) {
        console.error('❌ Setup failed:', error.message);
        process.exit(1);
    }
}

// Run if called directly
if (require.main === module) {
    main();
}

module.exports = {
    setupEnvironment,
    generateJWTSecret,
    generateApiKey
};
