#!/usr/bin/env node
/**
 * Change Admin Password Script
 * Updates the admin user password directly in the database
 */

const bcrypt = require('bcrypt');
const sqlite3 = require('sqlite3').verbose();
const { open } = require('sqlite');
const path = require('path');

// Load environment configuration
require('dotenv').config();
const { config } = require('../config/environment');

async function changeAdminPassword(username, newPassword) {
    let db = null;
    
    try {
        console.log('🔧 Connecting to database...');
        
        // Open database connection
        db = await open({
            filename: config.database.path,
            driver: sqlite3.Database
        });
        
        console.log('✅ Database connected');
        
        // Check if admin user exists
        const user = await db.get('SELECT * FROM admin_users WHERE username = ?', [username]);
        
        if (!user) {
            console.error(`❌ User '${username}' not found!`);
            process.exit(1);
        }
        
        console.log(`👤 Found user: ${user.username} (${user.email})`);
        
        // Validate new password
        if (newPassword.length < 8) {
            console.error('❌ Password must be at least 8 characters long');
            process.exit(1);
        }
        
        console.log('🔐 Hashing new password...');
        
        // Hash the new password
        const saltRounds = 12;
        const hashedPassword = await bcrypt.hash(newPassword, saltRounds);
        
        console.log('💾 Updating password in database...');
        
        // Update password in database
        const result = await db.run(`
            UPDATE admin_users 
            SET password_hash = ?, 
                password_changed_at = CURRENT_TIMESTAMP, 
                updated_at = CURRENT_TIMESTAMP,
                login_attempts = 0,
                locked_until = NULL
            WHERE username = ?
        `, [hashedPassword, username]);
        
        if (result.changes > 0) {
            console.log('✅ Password updated successfully!');
            console.log('');
            console.log('📋 Updated Admin Credentials:');
            console.log(`   Username: ${username}`);
            console.log(`   Password: ${newPassword}`);
            console.log(`   Email: ${user.email}`);
            console.log('');
            console.log('🔗 Login at: http://localhost:5173/admin/login');
            console.log('');
            console.log('⚠️  Keep this password secure and consider changing it again if needed.');
        } else {
            console.error('❌ Failed to update password - no changes made');
            process.exit(1);
        }
        
    } catch (error) {
        console.error('❌ Error:', error.message);
        process.exit(1);
    } finally {
        if (db) {
            await db.close();
            console.log('🔓 Database connection closed');
        }
    }
}

async function main() {
    const args = process.argv.slice(2);
    
    if (args.length < 1) {
        console.log('Change Admin Password Tool');
        console.log('=========================');
        console.log('Usage: node scripts/change-admin-password.js <new-password> [username]');
        console.log('');
        console.log('Examples:');
        console.log('  node scripts/change-admin-password.js "myNewPassword123!"');
        console.log('  node scripts/change-admin-password.js "myNewPassword123!" admin');
        console.log('');
        console.log('Default username is "admin" if not specified.');
        process.exit(1);
    }
    
    const newPassword = args[0];
    const username = args[1] || 'admin';
    
    console.log('🔑 BIOMIDDLEWARE - Change Admin Password');
    console.log('=' .repeat(50));
    console.log(`Target user: ${username}`);
    console.log(`New password length: ${newPassword.length} characters`);
    console.log('');
    
    await changeAdminPassword(username, newPassword);
}

// Run if called directly
if (require.main === module) {
    main();
}

module.exports = { changeAdminPassword };
