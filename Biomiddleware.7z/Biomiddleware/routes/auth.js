/**
 * Authentication Routes
 * Handles login/logout and admin authentication
 */

const express = require('express');
const router = express.Router();
const cookie = require('cookie-parser');
const authMiddleware = require('../middleware/auth');

/**
 * Initialize auth routes
 * @param {object} authService - Authentication service instance
 * @param {object} config - Environment configuration
 * @returns {express.Router} - Router instance
 */
function initAuthRoutes(authService, config) {
    // Add cookie parser
    router.use(cookie());
    
    // Add rate limiting and security headers
    router.use(authMiddleware.authRateLimit());
    router.use(authMiddleware.securityHeaders());
    router.use(authMiddleware.authLogger());
    router.use(authMiddleware.sessionCleanup(authService));
    
    /**
     * Login endpoint
     * POST /api/auth/login
     */
    router.post('/login', async (req, res) => {
        try {
            const { username, password, rememberMe } = req.body;
            
            if (!username || !password) {
                return res.status(400).json({
                    success: false,
                    error: 'Username and password are required',
                    code: 'MISSING_CREDENTIALS'
                });
            }
            
            const result = await authService.authenticate(username, password, rememberMe);
            
            // Set cookie for browser-based auth
            const cookieOptions = {
                httpOnly: true,
                secure: isProduction(config),
                sameSite: 'strict',
                maxAge: rememberMe ? 30 * 24 * 60 * 60 * 1000 : 24 * 60 * 60 * 1000
            };
            
            res.cookie('adminToken', result.token, cookieOptions);
            
            // Return success response
            return res.status(200).json({
                success: true,
                message: 'Authentication successful',
                token: result.token,
                user: {
                    id: result.user.id,
                    username: result.user.username,
                    role: result.user.role,
                    fullName: result.user.full_name,
                    lastLogin: result.user.last_login
                }
            });
            
        } catch (error) {
            console.error('Login error:', error.message);
            
            return res.status(401).json({
                success: false,
                error: error.message,
                code: 'AUTH_FAILED'
            });
        }
    });
    
    /**
     * Verify token endpoint
     * GET /api/auth/verify
     */
    router.get('/verify', authMiddleware.requireAuth(authService), (req, res) => {
        // If middleware passes, token is valid
        return res.status(200).json({
            success: true,
            message: 'Token is valid',
            user: {
                id: req.user.id,
                username: req.user.username,
                role: req.user.role
            }
        });
    });
    
    /**
     * Logout endpoint
     * POST /api/auth/logout
     */
    router.post('/logout', async (req, res) => {
        try {
            const token = authMiddleware.extractToken(req);
            
            if (token) {
                await authService.logout(token);
            }
            
            // Clear cookie
            res.clearCookie('adminToken');
            
            return res.status(200).json({
                success: true,
                message: 'Logout successful'
            });
            
        } catch (error) {
            console.error('Logout error:', error.message);
            
            // Still return success to client
            return res.status(200).json({
                success: true,
                message: 'Logout completed'
            });
        }
    });
    
    /**
     * Get user profile
     * GET /api/auth/profile
     */
    router.get('/profile', authMiddleware.requireAuth(authService), async (req, res) => {
        try {
            const userId = req.user.id;
            const profile = await authService.getUserProfile(userId);
            
            if (!profile) {
                return res.status(404).json({
                    success: false,
                    error: 'User profile not found',
                    code: 'PROFILE_NOT_FOUND'
                });
            }
            
            // Remove sensitive data
            delete profile.password_hash;
            delete profile.two_factor_secret;
            
            return res.status(200).json({
                success: true,
                profile
            });
            
        } catch (error) {
            console.error('Profile error:', error.message);
            
            return res.status(500).json({
                success: false,
                error: 'Failed to retrieve profile',
                code: 'PROFILE_ERROR'
            });
        }
    });
    
    /**
     * Update user profile
     * PUT /api/auth/profile
     */
    router.put('/profile', authMiddleware.requireAuth(authService), async (req, res) => {
        try {
            const userId = req.user.id;
            const updates = req.body;
            
            if (!updates || Object.keys(updates).length === 0) {
                return res.status(400).json({
                    success: false,
                    error: 'No updates provided',
                    code: 'NO_UPDATES'
                });
            }
            
            // Restrict fields that can be updated
            const allowedUpdates = {};
            const allowedFields = ['email', 'full_name'];
            
            for (const field of allowedFields) {
                if (updates[field] !== undefined) {
                    allowedUpdates[field] = updates[field];
                }
            }
            
            if (Object.keys(allowedUpdates).length === 0) {
                return res.status(400).json({
                    success: false,
                    error: 'No valid fields to update',
                    code: 'INVALID_UPDATES',
                    allowedFields
                });
            }
            
            await authService.updateUserProfile(userId, allowedUpdates);
            
            // Get updated profile
            const profile = await authService.getUserProfile(userId);
            
            return res.status(200).json({
                success: true,
                message: 'Profile updated successfully',
                profile
            });
            
        } catch (error) {
            console.error('Profile update error:', error.message);
            
            return res.status(500).json({
                success: false,
                error: error.message,
                code: 'PROFILE_UPDATE_ERROR'
            });
        }
    });
    
    /**
     * Change password
     * POST /api/auth/change-password
     */
    router.post('/change-password', authMiddleware.requireAuth(authService), async (req, res) => {
        try {
            const { currentPassword, newPassword } = req.body;
            const userId = req.user.id;
            
            if (!currentPassword || !newPassword) {
                return res.status(400).json({
                    success: false,
                    error: 'Current password and new password are required',
                    code: 'MISSING_PASSWORDS'
                });
            }
            
            await authService.changePassword(userId, currentPassword, newPassword);
            
            // Clear cookies to force re-login
            res.clearCookie('adminToken');
            
            return res.status(200).json({
                success: true,
                message: 'Password changed successfully. Please login again with your new password.',
                requireRelogin: true
            });
            
        } catch (error) {
            console.error('Password change error:', error.message);
            
            return res.status(400).json({
                success: false,
                error: error.message,
                code: 'PASSWORD_CHANGE_ERROR'
            });
        }
    });
    
    /**
     * Session info
     * GET /api/auth/session
     */
    router.get('/session', authMiddleware.requireAuth(authService), (req, res) => {
        if (!req.session) {
            return res.status(401).json({
                success: false,
                error: 'No active session',
                code: 'NO_SESSION'
            });
        }
        
        // Get session stats
        const sessionStats = authService.getSessionStats();
        
        return res.status(200).json({
            success: true,
            session: {
                id: req.session.id,
                createdAt: req.session.createdAt,
                expiresAt: req.session.expiresAt,
                lastActivity: req.session.lastActivity
            },
            stats: sessionStats
        });
    });

    return router;
}

// Helper functions
function isProduction(config) {
    return config.server.nodeEnv === 'production';
}

module.exports = initAuthRoutes;
