/**
 * Authentication Middleware
 * Provides middleware functions for protecting routes and validating admin access
 */

/**
 * Middleware to require admin authentication
 */
function requireAuth(authService) {
    return async (req, res, next) => {
        try {
            const token = extractToken(req);
            
            if (!token) {
                return res.status(401).json({
                    success: false,
                    error: 'Authentication required',
                    code: 'AUTH_REQUIRED'
                });
            }
            
            const session = await authService.validateSession(token);
            
            if (!session) {
                return res.status(401).json({
                    success: false,
                    error: 'Invalid or expired session',
                    code: 'SESSION_INVALID'
                });
            }
            
            // Add session info to request
            req.session = session;
            req.user = {
                id: session.userId,
                username: session.username,
                role: session.role
            };
            
            // Update session with request info
            session.ipAddress = getClientIP(req);
            session.userAgent = req.get('User-Agent');
            
            next();
            
        } catch (error) {
            console.error('Authentication middleware error:', error.message);
            
            return res.status(401).json({
                success: false,
                error: 'Authentication failed',
                code: 'AUTH_FAILED'
            });
        }
    };
}

/**
 * Middleware for optional authentication (doesn't block if not authenticated)
 */
function optionalAuth(authService) {
    return async (req, res, next) => {
        try {
            const token = extractToken(req);
            
            if (token) {
                try {
                    const session = await authService.validateSession(token);
                    
                    if (session) {
                        req.session = session;
                        req.user = {
                            id: session.userId,
                            username: session.username,
                            role: session.role
                        };
                        
                        // Update session with request info
                        session.ipAddress = getClientIP(req);
                        session.userAgent = req.get('User-Agent');
                    }
                } catch (error) {
                    // Ignore auth errors for optional auth
                }
            }
            
            next();
            
        } catch (error) {
            console.error('Optional auth middleware error:', error.message);
            next(); // Continue even if there's an error
        }
    };
}

/**
 * Middleware to check specific role requirements
 */
function requireRole(authService, requiredRoles) {
    const roles = Array.isArray(requiredRoles) ? requiredRoles : [requiredRoles];
    
    return async (req, res, next) => {
        // First check authentication
        const authMiddleware = requireAuth(authService);
        
        authMiddleware(req, res, (error) => {
            if (error) {
                return next(error);
            }
            
            // Check if user has required role
            if (!req.user || !roles.includes(req.user.role)) {
                return res.status(403).json({
                    success: false,
                    error: 'Insufficient permissions',
                    code: 'INSUFFICIENT_PERMISSIONS',
                    requiredRoles: roles,
                    userRole: req.user?.role
                });
            }
            
            next();
        });
    };
}

/**
 * Middleware to check if user is super admin
 */
function requireSuperAdmin(authService) {
    return requireRole(authService, 'super_admin');
}

/**
 * Middleware to check if user is admin or super admin
 */
function requireAdmin(authService) {
    return requireRole(authService, ['admin', 'super_admin']);
}

/**
 * Middleware to validate API key for device access
 */
function requireAPIKey(apiKeyManager) {
    return (req, res, next) => {
        const apiKey = req.headers['x-api-key'] || req.query.api_key;
        
        if (!apiKey) {
            return res.status(401).json({
                success: false,
                error: 'API key required',
                code: 'API_KEY_REQUIRED'
            });
        }
        
        const keyInfo = apiKeyManager.validateKey(apiKey);
        
        if (!keyInfo) {
            return res.status(401).json({
                success: false,
                error: 'Invalid or inactive API key',
                code: 'INVALID_API_KEY'
            });
        }
        
        // Add API key info to request
        req.apiKeyInfo = keyInfo;
        next();
    };
}

/**
 * Middleware to allow either admin auth or API key
 */
function requireAuthOrAPIKey(authService, apiKeyManager) {
    return async (req, res, next) => {
        // Try admin authentication first
        const token = extractToken(req);
        
        if (token) {
            try {
                const session = await authService.validateSession(token);
                
                if (session) {
                    req.session = session;
                    req.user = {
                        id: session.userId,
                        username: session.username,
                        role: session.role
                    };
                    
                    session.ipAddress = getClientIP(req);
                    session.userAgent = req.get('User-Agent');
                    
                    return next();
                }
            } catch (error) {
                // Fall through to API key check
            }
        }
        
        // Try API key authentication
        const apiKey = req.headers['x-api-key'] || req.query.api_key;
        
        if (apiKey) {
            const keyInfo = apiKeyManager.validateKey(apiKey);
            
            if (keyInfo) {
                req.apiKeyInfo = keyInfo;
                return next();
            }
        }
        
        // Neither authentication method worked
        return res.status(401).json({
            success: false,
            error: 'Authentication required (admin login or API key)',
            code: 'AUTH_REQUIRED'
        });
    };
}

/**
 * Rate limiting middleware for authentication endpoints
 */
function authRateLimit() {
    const attempts = new Map(); // IP -> { count, resetTime }
    const maxAttempts = 5;
    const windowMs = 15 * 60 * 1000; // 15 minutes
    
    return (req, res, next) => {
        const clientIP = getClientIP(req);
        const now = Date.now();
        
        // Clean up old entries
        for (const [ip, data] of attempts.entries()) {
            if (now > data.resetTime) {
                attempts.delete(ip);
            }
        }
        
        const clientAttempts = attempts.get(clientIP);
        
        if (clientAttempts && clientAttempts.count >= maxAttempts) {
            const timeRemaining = Math.ceil((clientAttempts.resetTime - now) / 60000);
            
            return res.status(429).json({
                success: false,
                error: `Too many authentication attempts. Try again in ${timeRemaining} minutes.`,
                code: 'RATE_LIMITED',
                retryAfter: timeRemaining * 60
            });
        }
        
        // Increment attempts on failed login
        const originalSend = res.send;
        res.send = function(body) {
            try {
                const responseData = typeof body === 'string' ? JSON.parse(body) : body;
                
                if (!responseData.success && (req.path.includes('/login') || req.path.includes('/auth'))) {
                    const existingAttempts = attempts.get(clientIP);
                    
                    attempts.set(clientIP, {
                        count: existingAttempts ? existingAttempts.count + 1 : 1,
                        resetTime: now + windowMs
                    });
                }
            } catch (error) {
                // Ignore JSON parsing errors
            }
            
            originalSend.call(this, body);
        };
        
        next();
    };
}

/**
 * Security headers middleware
 */
function securityHeaders() {
    return (req, res, next) => {
        // Only set security headers for admin routes
        if (req.path.startsWith('/admin') || req.path.startsWith('/api/auth')) {
            res.setHeader('X-Content-Type-Options', 'nosniff');
            res.setHeader('X-Frame-Options', 'DENY');
            res.setHeader('X-XSS-Protection', '1; mode=block');
            res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
            
            // Don't cache sensitive pages
            res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
            res.setHeader('Pragma', 'no-cache');
            res.setHeader('Expires', '0');
        }
        
        next();
    };
}

/**
 * Request logging middleware for authentication events
 */
function authLogger() {
    return (req, res, next) => {
        const startTime = Date.now();
        const clientIP = getClientIP(req);
        
        // Log authentication-related requests
        if (req.path.startsWith('/api/auth') || req.path.startsWith('/admin')) {
            const originalSend = res.send;
            
            res.send = function(body) {
                const duration = Date.now() - startTime;
                let responseData;
                
                try {
                    responseData = typeof body === 'string' ? JSON.parse(body) : body;
                } catch (error) {
                    responseData = { success: false };
                }
                
                const logData = {
                    timestamp: new Date().toISOString(),
                    method: req.method,
                    path: req.path,
                    ip: clientIP,
                    userAgent: req.get('User-Agent'),
                    duration: `${duration}ms`,
                    status: res.statusCode,
                    success: responseData.success,
                    user: req.user?.username || 'anonymous'
                };
                
                const level = res.statusCode >= 400 ? 'warn' : 'info';
                console.log(`🔐 [${level.toUpperCase()}] ${JSON.stringify(logData)}`);
                
                originalSend.call(this, body);
            };
        }
        
        next();
    };
}

/**
 * Extract token from request (header or cookie)
 */
function extractToken(req) {
    // Check Authorization header
    const authHeader = req.get('Authorization');
    if (authHeader && authHeader.startsWith('Bearer ')) {
        return authHeader.slice(7);
    }
    
    // Check cookies
    if (req.cookies && req.cookies.adminToken) {
        return req.cookies.adminToken;
    }
    
    return null;
}

/**
 * Get client IP address
 */
function getClientIP(req) {
    return req.ip || 
           req.connection.remoteAddress || 
           req.socket.remoteAddress || 
           (req.connection.socket ? req.connection.socket.remoteAddress : null) ||
           'unknown';
}

/**
 * Session cleanup middleware (for logout)
 */
function sessionCleanup(authService) {
    return async (req, res, next) => {
        const token = extractToken(req);
        
        if (token && req.method === 'POST' && req.path.includes('/logout')) {
            try {
                await authService.logout(token);
            } catch (error) {
                console.error('Session cleanup error:', error.message);
            }
        }
        
        next();
    };
}

/**
 * Middleware to add user context to all requests
 */
function addUserContext(authService) {
    return async (req, res, next) => {
        const token = extractToken(req);
        
        if (token) {
            try {
                const session = await authService.validateSession(token);
                
                if (session) {
                    req.session = session;
                    req.user = {
                        id: session.userId,
                        username: session.username,
                        role: session.role
                    };
                    
                    // Add helper methods
                    req.isAuthenticated = () => true;
                    req.hasRole = (role) => session.role === role;
                    req.isSuperAdmin = () => session.role === 'super_admin';
                    req.isAdmin = () => ['admin', 'super_admin'].includes(session.role);
                } else {
                    req.isAuthenticated = () => false;
                    req.hasRole = () => false;
                    req.isSuperAdmin = () => false;
                    req.isAdmin = () => false;
                }
            } catch (error) {
                req.isAuthenticated = () => false;
                req.hasRole = () => false;
                req.isSuperAdmin = () => false;
                req.isAdmin = () => false;
            }
        } else {
            req.isAuthenticated = () => false;
            req.hasRole = () => false;
            req.isSuperAdmin = () => false;
            req.isAdmin = () => false;
        }
        
        next();
    };
}

module.exports = {
    requireAuth,
    optionalAuth,
    requireRole,
    requireSuperAdmin,
    requireAdmin,
    requireAPIKey,
    requireAuthOrAPIKey,
    authRateLimit,
    securityHeaders,
    authLogger,
    sessionCleanup,
    addUserContext,
    extractToken,
    getClientIP
};
