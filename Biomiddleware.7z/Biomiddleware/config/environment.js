#!/usr/bin/env node
/**
 * Environment Configuration Loader
 * Loads and validates environment variables with sensible defaults
 */

require('dotenv').config();

/**
 * Parse environment variable as boolean
 * @param {string} value - Environment variable value
 * @param {boolean} defaultValue - Default value if not set
 * @returns {boolean}
 */
function parseBoolean(value, defaultValue = false) {
    if (value === undefined || value === '') return defaultValue;
    return value.toLowerCase() === 'true' || value === '1';
}

/**
 * Parse environment variable as integer
 * @param {string} value - Environment variable value
 * @param {number} defaultValue - Default value if not set
 * @returns {number}
 */
function parseInt(value, defaultValue = 0) {
    if (value === undefined || value === '') return defaultValue;
    const parsed = Number.parseInt(value, 10);
    return isNaN(parsed) ? defaultValue : parsed;
}

/**
 * Parse environment variable as array
 * @param {string} value - Environment variable value (comma-separated)
 * @param {string[]} defaultValue - Default value if not set
 * @returns {string[]}
 */
function parseArray(value, defaultValue = []) {
    if (value === undefined || value === '') return defaultValue;
    return value.split(',').map(item => item.trim()).filter(Boolean);
}

/**
 * Environment configuration object
 */
const config = {
    // Server Configuration
    server: {
        nodeEnv: process.env.NODE_ENV || 'development',
        port: parseInt(process.env.PORT, 5173),
        host: process.env.HOST || 'localhost',
        apiVersion: process.env.API_VERSION || 'v1',
        apiBasePath: process.env.API_BASE_PATH || '/api'
    },

    // Database Configuration
    database: {
        path: process.env.DB_PATH || './data/biometric.db',
        backupPath: process.env.DB_BACKUP_PATH || './data/backups/',
        autoBackup: parseBoolean(process.env.DB_AUTO_BACKUP, true),
        backupInterval: parseInt(process.env.DB_BACKUP_INTERVAL, 3600000) // 1 hour
    },

    // Security Configuration
    security: {
        jwtSecret: process.env.JWT_SECRET || 'default-jwt-secret-change-in-production',
        jwtExpiresIn: process.env.JWT_EXPIRES_IN || '24h',
        rateLimitWindowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS, 900000), // 15 minutes
        rateLimitMaxRequests: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS, 1000),
        defaultApiKeyName: process.env.DEFAULT_API_KEY_NAME || 'System Default',
        defaultApiKeyDeviceId: process.env.DEFAULT_API_KEY_DEVICE_ID || 'system'
    },

    // Device Configuration
    device: {
        defaultTimeout: parseInt(process.env.DEFAULT_DEVICE_TIMEOUT, 30000),
        defaultRetryAttempts: parseInt(process.env.DEFAULT_DEVICE_RETRY_ATTEMPTS, 3),
        defaultRetryDelay: parseInt(process.env.DEFAULT_DEVICE_RETRY_DELAY, 2000),
        autoDiscoveryEnabled: parseBoolean(process.env.AUTO_DISCOVERY_ENABLED, true),
        autoDiscoveryNetwork: process.env.AUTO_DISCOVERY_NETWORK || '192.168.1.0/24',
        autoDiscoveryTimeout: parseInt(process.env.AUTO_DISCOVERY_TIMEOUT, 5000),
        syncEnabled: parseBoolean(process.env.DEVICE_SYNC_ENABLED, true),
        syncInterval: parseInt(process.env.DEVICE_SYNC_INTERVAL, 60000), // 1 minute
        autoSyncOnStartup: parseBoolean(process.env.AUTO_SYNC_ON_STARTUP, true)
    },

    // Branch Configuration
    branch: {
        defaultBranchId: process.env.DEFAULT_BRANCH_ID || 'main',
        defaultBranchName: process.env.DEFAULT_BRANCH_NAME || 'Main Branch',
        defaultTimezone: process.env.DEFAULT_BRANCH_TIMEZONE || 'UTC'
    },

    // Logging Configuration
    logging: {
        level: process.env.LOG_LEVEL || 'info',
        format: process.env.LOG_FORMAT || 'combined',
        fileEnabled: parseBoolean(process.env.LOG_FILE_ENABLED, false),
        filePath: process.env.LOG_FILE_PATH || './logs/biomiddleware.log',
        consoleEnabled: parseBoolean(process.env.CONSOLE_LOG_ENABLED, true),
        consoleColors: parseBoolean(process.env.CONSOLE_LOG_COLORS, true)
    },

    // Performance Settings
    performance: {
        maxMemoryUsage: process.env.MAX_MEMORY_USAGE || '512MB',
        gcInterval: parseInt(process.env.GC_INTERVAL, 300000), // 5 minutes
        maxConcurrentConnections: parseInt(process.env.MAX_CONCURRENT_CONNECTIONS, 100),
        connectionTimeout: parseInt(process.env.CONNECTION_TIMEOUT, 30000),
        maxFileSize: process.env.MAX_FILE_SIZE || '10MB',
        maxFilesPerRequest: parseInt(process.env.MAX_FILES_PER_REQUEST, 5)
    },

    // CORS Configuration
    cors: {
        enabled: parseBoolean(process.env.CORS_ENABLED, true),
        origin: process.env.CORS_ORIGIN || '*',
        methods: parseArray(process.env.CORS_METHODS, ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS']),
        headers: parseArray(process.env.CORS_HEADERS, ['Content-Type', 'Authorization', 'X-API-Key', 'X-Device-ID'])
    },

    // Attendance Settings
    attendance: {
        logRetentionDays: parseInt(process.env.ATTENDANCE_LOG_RETENTION_DAYS, 365),
        autoCleanup: parseBoolean(process.env.ATTENDANCE_AUTO_CLEANUP, true),
        cleanupInterval: parseInt(process.env.ATTENDANCE_CLEANUP_INTERVAL, 86400000), // 24 hours
        uploaderEnabled: parseBoolean(process.env.ATTENDANCE_UPLOADER_ENABLED, false),
        uploaderUrl: process.env.ATTENDANCE_UPLOADER_URL || '',
        uploaderInterval: parseInt(process.env.ATTENDANCE_UPLOADER_INTERVAL, 300000), // 5 minutes
        uploaderRetryAttempts: parseInt(process.env.ATTENDANCE_UPLOADER_RETRY_ATTEMPTS, 3)
    },

    // HR System Integration
    hr: {
        employeePhotoPath: process.env.EMPLOYEE_PHOTO_PATH || './data/photos/',
        employeeBackupEnabled: parseBoolean(process.env.EMPLOYEE_BACKUP_ENABLED, true),
        payrollCalculationEnabled: parseBoolean(process.env.PAYROLL_CALCULATION_ENABLED, true),
        payrollOvertimeThreshold: parseInt(process.env.PAYROLL_OVERTIME_THRESHOLD, 8),
        payrollDefaultCurrency: process.env.PAYROLL_DEFAULT_CURRENCY || 'USD'
    },

    // Network Configuration
    network: {
        scanEnabled: parseBoolean(process.env.NETWORK_SCAN_ENABLED, true),
        scanTimeout: parseInt(process.env.NETWORK_SCAN_TIMEOUT, 5000),
        scanPorts: parseArray(process.env.NETWORK_SCAN_PORTS, ['80', '443', '8080']),
        httpProxy: process.env.HTTP_PROXY || '',
        httpsProxy: process.env.HTTPS_PROXY || '',
        noProxy: parseArray(process.env.NO_PROXY, ['localhost', '127.0.0.1'])
    },

    // Backup & Recovery
    backup: {
        autoBackupEnabled: parseBoolean(process.env.AUTO_BACKUP_ENABLED, true),
        autoBackupInterval: parseInt(process.env.AUTO_BACKUP_INTERVAL, 3600000), // 1 hour
        backupRetentionDays: parseInt(process.env.BACKUP_RETENTION_DAYS, 30),
        backupCompression: parseBoolean(process.env.BACKUP_COMPRESSION, true),
        exportFormat: process.env.EXPORT_FORMAT || 'json',
        exportPath: process.env.EXPORT_PATH || './exports/'
    },

    // Monitoring & Health
    monitoring: {
        healthCheckEnabled: parseBoolean(process.env.HEALTH_CHECK_ENABLED, true),
        healthCheckInterval: parseInt(process.env.HEALTH_CHECK_INTERVAL, 30000),
        healthCheckTimeout: parseInt(process.env.HEALTH_CHECK_TIMEOUT, 5000),
        performanceMonitoring: parseBoolean(process.env.PERFORMANCE_MONITORING, true),
        metricsCollection: parseBoolean(process.env.METRICS_COLLECTION, true)
    },

    // Development Settings
    development: {
        autoReload: parseBoolean(process.env.DEV_AUTO_RELOAD, true),
        mockDevices: parseBoolean(process.env.DEV_MOCK_DEVICES, false),
        debugSql: parseBoolean(process.env.DEV_DEBUG_SQL, false),
        verboseLogging: parseBoolean(process.env.DEV_VERBOSE_LOGGING, false)
    },

    // Testing Settings
    testing: {
        databasePath: process.env.TEST_DATABASE_PATH || './test-data/test.db',
        port: parseInt(process.env.TEST_PORT, 0),
        timeout: parseInt(process.env.TEST_TIMEOUT, 10000)
    },

    // Feature Flags
    features: {
        branchManagement: parseBoolean(process.env.FEATURE_BRANCH_MANAGEMENT, true),
        hrIntegration: parseBoolean(process.env.FEATURE_HR_INTEGRATION, true),
        payrollSystem: parseBoolean(process.env.FEATURE_PAYROLL_SYSTEM, true),
        deviceDiscovery: parseBoolean(process.env.FEATURE_DEVICE_DISCOVERY, true),
        autoSync: parseBoolean(process.env.FEATURE_AUTO_SYNC, true),
        backupSystem: parseBoolean(process.env.FEATURE_BACKUP_SYSTEM, true),
        apiRateLimiting: parseBoolean(process.env.FEATURE_API_RATE_LIMITING, true)
    },

    // Experimental Features
    experimental: {
        websockets: parseBoolean(process.env.EXPERIMENTAL_WEBSOCKETS, false),
        realTimeSync: parseBoolean(process.env.EXPERIMENTAL_REAL_TIME_SYNC, false),
        cloudBackup: parseBoolean(process.env.EXPERIMENTAL_CLOUD_BACKUP, false)
    },

    // Third-party Integrations
    integrations: {
        email: {
            enabled: parseBoolean(process.env.EMAIL_ENABLED, false),
            smtpHost: process.env.EMAIL_SMTP_HOST || '',
            smtpPort: parseInt(process.env.EMAIL_SMTP_PORT, 587),
            smtpUser: process.env.EMAIL_SMTP_USER || '',
            smtpPass: process.env.EMAIL_SMTP_PASS || '',
            fromAddress: process.env.EMAIL_FROM_ADDRESS || 'noreply@biomiddleware.com'
        },
        cloudStorage: {
            enabled: parseBoolean(process.env.CLOUD_STORAGE_ENABLED, false),
            provider: process.env.CLOUD_STORAGE_PROVIDER || 's3',
            bucket: process.env.CLOUD_STORAGE_BUCKET || '',
            region: process.env.CLOUD_STORAGE_REGION || '',
            accessKey: process.env.CLOUD_STORAGE_ACCESS_KEY || '',
            secretKey: process.env.CLOUD_STORAGE_SECRET_KEY || ''
        },
        webhooks: {
            enabled: parseBoolean(process.env.WEBHOOK_ENABLED, false),
            url: process.env.WEBHOOK_URL || '',
            secret: process.env.WEBHOOK_SECRET || '',
            events: parseArray(process.env.WEBHOOK_EVENTS, ['device.connected', 'device.disconnected', 'attendance.recorded'])
        }
    },

    // Advanced Configuration
    advanced: {
        customProtocol: {
            enabled: parseBoolean(process.env.CUSTOM_PROTOCOL_ENABLED, false),
            path: process.env.CUSTOM_PROTOCOL_PATH || './protocols/'
        },
        pluginSystem: {
            enabled: parseBoolean(process.env.PLUGIN_SYSTEM_ENABLED, false),
            path: process.env.PLUGIN_PATH || './plugins/'
        },
        customThemes: {
            enabled: parseBoolean(process.env.CUSTOM_THEMES_ENABLED, false),
            path: process.env.CUSTOM_THEMES_PATH || './themes/'
        }
    }
};

/**
 * Validate critical configuration values
 */
function validateConfig() {
    const errors = [];
    
    // Check critical security settings in production
    if (config.server.nodeEnv === 'production') {
        if (config.security.jwtSecret === 'default-jwt-secret-change-in-production') {
            errors.push('JWT_SECRET must be changed in production environment');
        }
        
        if (config.cors.origin === '*') {
            console.warn('⚠️ CORS origin is set to * in production. Consider restricting to specific domains.');
        }
    }
    
    // Validate required directories exist
    const requiredDirs = [
        config.database.path.substring(0, config.database.path.lastIndexOf('/')),
        config.database.backupPath,
        config.hr.employeePhotoPath,
        config.backup.exportPath
    ].filter(Boolean);
    
    // Return validation results
    return {
        isValid: errors.length === 0,
        errors,
        warnings: [],
        requiredDirectories: requiredDirs
    };
}

/**
 * Get configuration value by dot notation path
 * @param {string} path - Dot notation path (e.g., 'server.port')
 * @returns {any} Configuration value
 */
function get(path) {
    return path.split('.').reduce((obj, key) => obj?.[key], config);
}

/**
 * Check if running in development mode
 * @returns {boolean}
 */
function isDevelopment() {
    return config.server.nodeEnv === 'development';
}

/**
 * Check if running in production mode
 * @returns {boolean}
 */
function isProduction() {
    return config.server.nodeEnv === 'production';
}

/**
 * Check if running in test mode
 * @returns {boolean}
 */
function isTest() {
    return config.server.nodeEnv === 'test';
}

module.exports = {
    config,
    get,
    isDevelopment,
    isProduction,
    isTest,
    validateConfig
};
