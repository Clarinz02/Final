/**
 * Admin Dashboard JavaScript
 * Handles authentication, UI interactions, and API calls for the admin panel
 */

class AdminDashboard {
    constructor() {
        this.token = this.getToken();
        this.currentUser = null;
        this.refreshInterval = null;
        
        this.initializeAuth();
        this.initializeEventListeners();
        this.loadInitialData();
        this.startAutoRefresh();
    }

    /**
     * Get authentication token from storage
     */
    getToken() {
        return localStorage.getItem('adminToken') || sessionStorage.getItem('adminToken');
    }

    /**
     * Set authentication token
     */
    setToken(token, remember = false) {
        if (remember) {
            localStorage.setItem('adminToken', token);
        } else {
            sessionStorage.setItem('adminToken', token);
        }
    }

    /**
     * Remove authentication token
     */
    removeToken() {
        localStorage.removeItem('adminToken');
        sessionStorage.removeItem('adminToken');
    }

    /**
     * Initialize authentication check
     */
    async initializeAuth() {
        if (!this.token) {
            this.redirectToLogin();
            return;
        }

        try {
            const response = await this.apiCall('/api/auth/verify', 'GET');
            if (response.success) {
                this.currentUser = response.user;
                this.updateUserInterface();
            } else {
                this.redirectToLogin();
            }
        } catch (error) {
            console.error('Auth verification failed:', error);
            this.redirectToLogin();
        }
    }

    /**
     * Redirect to login page
     */
    redirectToLogin() {
        window.location.href = '/admin/login';
    }

    /**
     * Update user interface with user info
     */
    updateUserInterface() {
        if (this.currentUser) {
            const userNameElement = document.getElementById('userName');
            const userAvatarElement = document.getElementById('userAvatar');
            
            userNameElement.textContent = this.currentUser.username;
            userAvatarElement.textContent = this.currentUser.username.charAt(0).toUpperCase();
        }
    }

    /**
     * Initialize event listeners
     */
    initializeEventListeners() {
        // Profile form
        const profileForm = document.getElementById('profileForm');
        if (profileForm) {
            profileForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.updateProfile();
            });
        }

        // Password form
        const passwordForm = document.getElementById('passwordForm');
        if (passwordForm) {
            passwordForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.changePassword();
            });
        }

        // Close modal when clicking outside
        window.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal')) {
                e.target.style.display = 'none';
            }
        });
    }

    /**
     * Load initial dashboard data
     */
    async loadInitialData() {
        await Promise.all([
            this.loadSystemStats(),
            this.loadSessionInfo(),
            this.loadUserProfile()
        ]);
    }

    /**
     * Start auto-refresh for dashboard data
     */
    startAutoRefresh() {
        // Refresh stats every 30 seconds
        this.refreshInterval = setInterval(() => {
            this.loadSystemStats();
            this.loadSessionInfo();
        }, 30000);
    }

    /**
     * Stop auto-refresh
     */
    stopAutoRefresh() {
        if (this.refreshInterval) {
            clearInterval(this.refreshInterval);
            this.refreshInterval = null;
        }
    }

    /**
     * Make authenticated API call
     */
    async apiCall(endpoint, method = 'GET', data = null) {
        const options = {
            method,
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${this.token}`
            }
        };

        if (data && (method === 'POST' || method === 'PUT' || method === 'PATCH')) {
            options.body = JSON.stringify(data);
        }

        const response = await fetch(endpoint, options);
        const result = await response.json();

        if (!response.ok) {
            throw new Error(result.error || `HTTP ${response.status}`);
        }

        return result;
    }

    /**
     * Load system statistics
     */
    async loadSystemStats() {
        try {
            // Load devices overview
            const devicesResponse = await this.apiCall('/api/devices');
            if (devicesResponse.success) {
                document.getElementById('connectedDevices').textContent = 
                    devicesResponse.data.connectedDevices || 0;
            }

            // Load employees count
            const employeesResponse = await this.apiCall('/api/employees/stats');
            if (employeesResponse.success) {
                document.getElementById('totalEmployees').textContent = 
                    employeesResponse.data.totalEmployees || 0;
            }

            // Load branches count
            const branchesResponse = await this.apiCall('/api/branches/stats');
            if (branchesResponse.success) {
                document.getElementById('activeBranches').textContent = 
                    branchesResponse.data.totalBranches || 0;
            }

            // Load today's attendance
            const attendanceResponse = await this.apiCall('/api/attendance/today');
            if (attendanceResponse.success) {
                document.getElementById('todayAttendance').textContent = 
                    attendanceResponse.data.totalPresent || 0;
            }

        } catch (error) {
            console.error('Failed to load system stats:', error);
        }
    }

    /**
     * Load session information
     */
    async loadSessionInfo() {
        try {
            const response = await this.apiCall('/api/auth/session');
            if (response.success) {
                document.getElementById('activeSessions').textContent = 
                    response.stats.active || 1;
            }
        } catch (error) {
            console.error('Failed to load session info:', error);
        }
    }

    /**
     * Load user profile data
     */
    async loadUserProfile() {
        try {
            const response = await this.apiCall('/api/auth/profile');
            if (response.success) {
                const profile = response.profile;
                
                // Populate profile form
                document.getElementById('profileUsername').value = profile.username || '';
                document.getElementById('profileEmail').value = profile.email || '';
                document.getElementById('profileFullName').value = profile.full_name || '';
                document.getElementById('profileRole').value = profile.role || '';
            }
        } catch (error) {
            console.error('Failed to load user profile:', error);
        }
    }

    /**
     * Update user profile
     */
    async updateProfile() {
        try {
            const formData = {
                email: document.getElementById('profileEmail').value,
                full_name: document.getElementById('profileFullName').value
            };

            const response = await this.apiCall('/api/auth/profile', 'PUT', formData);
            
            if (response.success) {
                this.showAlert('profileAlert', 'Profile updated successfully!', 'success');
                
                // Update current user info
                this.currentUser.fullName = formData.full_name;
            } else {
                this.showAlert('profileAlert', response.error || 'Failed to update profile', 'error');
            }
        } catch (error) {
            this.showAlert('profileAlert', error.message, 'error');
        }
    }

    /**
     * Change password
     */
    async changePassword() {
        const currentPassword = document.getElementById('currentPassword').value;
        const newPassword = document.getElementById('newPassword').value;
        const confirmPassword = document.getElementById('confirmPassword').value;

        // Client-side validation
        if (!currentPassword || !newPassword || !confirmPassword) {
            this.showAlert('passwordAlert', 'All fields are required', 'error');
            return;
        }

        if (newPassword !== confirmPassword) {
            this.showAlert('passwordAlert', 'New passwords do not match', 'error');
            return;
        }

        if (newPassword.length < 8) {
            this.showAlert('passwordAlert', 'New password must be at least 8 characters long', 'error');
            return;
        }

        try {
            const response = await this.apiCall('/api/auth/change-password', 'POST', {
                currentPassword,
                newPassword
            });

            if (response.success) {
                this.showAlert('passwordAlert', 'Password changed successfully! Please login again.', 'success');
                
                // Clear form
                document.getElementById('passwordForm').reset();
                
                // Redirect to login after 2 seconds
                setTimeout(() => {
                    this.logout();
                }, 2000);
            } else {
                this.showAlert('passwordAlert', response.error || 'Failed to change password', 'error');
            }
        } catch (error) {
            this.showAlert('passwordAlert', error.message, 'error');
        }
    }

    /**
     * Show alert in modal
     */
    showAlert(containerId, message, type = 'info') {
        const container = document.getElementById(containerId);
        container.innerHTML = `<div class="alert alert-${type}">${message}</div>`;
        
        // Auto-hide success alerts after 5 seconds
        if (type === 'success') {
            setTimeout(() => {
                container.innerHTML = '';
            }, 5000);
        }
    }

    /**
     * Show modal
     */
    showModal(modalId) {
        document.getElementById(modalId).style.display = 'block';
    }

    /**
     * Close modal
     */
    closeModal(modalId) {
        document.getElementById(modalId).style.display = 'none';
        
        // Clear alerts when closing modal
        const alerts = document.querySelectorAll(`#${modalId} .alert`);
        alerts.forEach(alert => alert.remove());
    }

    /**
     * Logout user
     */
    async logout() {
        try {
            await this.apiCall('/api/auth/logout', 'POST');
        } catch (error) {
            console.error('Logout error:', error);
        } finally {
            this.removeToken();
            this.stopAutoRefresh();
            this.redirectToLogin();
        }
    }

    /**
     * Refresh statistics
     */
    async refreshStats() {
        const refreshBtn = event.target.closest('.action-btn');
        const originalHTML = refreshBtn.innerHTML;
        
        refreshBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i><span>Refreshing...</span>';
        refreshBtn.disabled = true;

        try {
            await this.loadSystemStats();
            await this.loadSessionInfo();
        } catch (error) {
            console.error('Failed to refresh stats:', error);
        } finally {
            refreshBtn.innerHTML = originalHTML;
            refreshBtn.disabled = false;
        }
    }

    /**
     * Export system data
     */
    async exportData() {
        try {
            // This would typically call an export endpoint
            alert('Data export functionality will be implemented based on your specific requirements.');
        } catch (error) {
            console.error('Export failed:', error);
            alert('Export failed: ' + error.message);
        }
    }

    /**
     * Backup database
     */
    async backupDatabase() {
        try {
            const response = await this.apiCall('/api/system/backup', 'POST');
            if (response.success) {
                alert('Database backup completed successfully!');
            } else {
                alert('Backup failed: ' + response.error);
            }
        } catch (error) {
            console.error('Backup failed:', error);
            alert('Backup failed: ' + error.message);
        }
    }

    /**
     * View system logs
     */
    viewLogs() {
        // Open logs in a new window or modal
        window.open('/api/system/logs', '_blank');
    }

    /**
     * Restart system
     */
    async restartSystem() {
        if (confirm('Are you sure you want to restart the system? This will disconnect all active sessions.')) {
            try {
                await this.apiCall('/api/system/restart', 'POST');
                alert('System restart initiated. The page will reload automatically.');
                
                // Wait a few seconds then reload
                setTimeout(() => {
                    window.location.reload();
                }, 5000);
            } catch (error) {
                console.error('Restart failed:', error);
                alert('Restart failed: ' + error.message);
            }
        }
    }
}

// Global functions for HTML onclick handlers
function showProfileModal() {
    dashboard.showModal('profileModal');
}

function showPasswordModal() {
    dashboard.showModal('passwordModal');
}

function showSettingsModal() {
    dashboard.showModal('settingsModal');
}

function closeModal(modalId) {
    dashboard.closeModal(modalId);
}

function logout() {
    dashboard.logout();
}

function refreshStats() {
    dashboard.refreshStats();
}

function exportData() {
    dashboard.exportData();
}

function backupDatabase() {
    dashboard.backupDatabase();
}

function viewLogs() {
    dashboard.viewLogs();
}

function restartSystem() {
    dashboard.restartSystem();
}

// Initialize dashboard when DOM is loaded
let dashboard;
document.addEventListener('DOMContentLoaded', () => {
    dashboard = new AdminDashboard();
});

// Handle page visibility changes
document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible' && dashboard) {
        // Refresh data when page becomes visible
        dashboard.loadSystemStats();
    }
});

// Handle beforeunload to clean up
window.addEventListener('beforeunload', () => {
    if (dashboard) {
        dashboard.stopAutoRefresh();
    }
});
