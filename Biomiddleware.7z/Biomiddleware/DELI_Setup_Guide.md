# DELI Biometric Scanner Setup Guide

## 🎉 DELI Full Compatibility Confirmed!

DELI biometric scanners are **100% compatible** with BIOMIDDLEWARE using the exact same protocol as ZKTeco devices.

## 📋 Prerequisites

### DELI Device Requirements:
- DELI biometric scanner with network connectivity
- HTTP interface enabled (factory default)
- Firmware supporting offline SDK protocol
- Network access to the device

### Network Setup:
- DELI device connected to network
- Static or DHCP IP address assigned
- Port 80 accessible for HTTP (or 443 for HTTPS)
- Firewall rules allowing communication

## 🚀 Quick Setup Steps

### Step 1: Find DELI Device IP
```bash
# Method 1: Check DELI device display/menu for IP address
# Method 2: Use network scanner
nmap -sn 192.168.1.0/24

# Method 3: Check router's connected devices
```

### Step 2: Test DELI Connectivity
```bash
# Test basic connectivity
ping [DELI_IP_ADDRESS]

# Test HTTP port
telnet [DELI_IP_ADDRESS] 80

# Test API endpoint
curl -X POST http://[DELI_IP_ADDRESS]/control \
  -H "Content-Type: application/json" \
  -d '{"mid":"test123","cmd":"GetVersionInfo","payload":{}}'
```

### Step 3: Add DELI to BIOMIDDLEWARE

#### Option A: Using Web Interface
1. Start BIOMIDDLEWARE server:
   ```bash
   cd /home/yna/Biomiddleware
   npm start
   ```

2. Open browser: `http://localhost:5173`

3. Navigate to **Device Manager** section

4. Click **"Add Device"** or use **Quick Add Device**:
   - **IP Address**: [Your DELI device IP]
   - **Port**: 80 (default)
   - **Device Name**: "DELI Scanner" (or custom name)
   - **Branch**: Select appropriate branch
   - **Auto Connect**: ✅ (recommended)

5. Click **"Add Device"**

#### Option B: Using API
```bash
curl -X POST http://localhost:5173/api/devices/quick-add \
  -H "Content-Type: application/json" \
  -d '{
    "ip": "[DELI_IP_ADDRESS]",
    "port": 80,
    "deviceName": "DELI Scanner",
    "branch": "main",
    "autoConnect": true
  }'
```

## 🔐 Security Configuration (Optional)

### Set API Key for DELI Device
If you want to secure your DELI device with an API key:

```javascript
// Using BIOMIDDLEWARE interface
// 1. Go to API Keys section
// 2. Generate new API key for DELI device
// 3. Configure DELI device with the key:

await device.setSecurityConfig({
    apiKey: "your-generated-api-key",
    enableHttp: true,
    enableHttps: false
});
```

## 📊 Supported Features

### ✅ Fully Supported DELI Features:
- **User Management**: Add, edit, delete biometric users
- **Face Recognition**: Enroll and manage face templates
- **Fingerprint**: Multiple finger enrollment
- **Card/RFID**: Card-based access
- **Palm Recognition**: Palm template management
- **Attendance Tracking**: Real-time attendance logs
- **Device Control**: Lock/unlock, time sync, settings
- **Network Configuration**: Ethernet and WiFi setup
- **Biometric Enrollment**: Remote enrollment via web interface

### 📋 DELI-Specific Commands:
All standard commands work with DELI devices:
- `GetUserInfo` / `SetUserInfo`
- `BeginEnrollFace` / `BeginEnrollFP`
- `GetAttendLog` / `EraseAttendLog`
- `GetDeviceTime` / `SetDeviceTime`
- `LockDevice` / `GetVersionInfo`

## 🌐 Network Scanner Integration

BIOMIDDLEWARE's network scanner will automatically detect DELI devices:

```bash
# Auto-discovery will find DELI devices on network
# Look for devices responding on port 80 with /control endpoint
```

## 🔧 Advanced Configuration

### HTTPS Setup (Optional)
```javascript
// Enable HTTPS on DELI device
await device.setSecurityConfig({
    enableHttps: true,
    enableHttp: false,
    validateCertificate: true
});

// Then connect using HTTPS
const deliDevice = new BiometricDeviceMiddleware(
    'DELI_IP_ADDRESS', 
    'api_key', 
    true  // useHttps = true
);
```

### Multiple DELI Devices
```javascript
// Add multiple DELI devices to different branches
const devices = [
    { ip: '192.168.1.100', branch: 'main-office', name: 'DELI Main' },
    { ip: '192.168.1.101', branch: 'warehouse', name: 'DELI Warehouse' },
    { ip: '192.168.1.102', branch: 'reception', name: 'DELI Reception' }
];

// BIOMIDDLEWARE will manage all simultaneously
```

## 🧪 Testing DELI Integration

### Basic Functionality Test:
```bash
# 1. Start BIOMIDDLEWARE
npm start

# 2. Add DELI device via web interface

# 3. Test basic operations:
#    - Get device info
#    - List users
#    - Sync time
#    - Test attendance log retrieval

# 4. Test biometric enrollment:
#    - Face enrollment via photo upload
#    - Fingerprint enrollment
#    - User management
```

### Verification Checklist:
- [ ] DELI device appears in device list
- [ ] Connection status shows "Online"
- [ ] Device info displays correctly
- [ ] Can retrieve user list
- [ ] Time synchronization works
- [ ] Attendance logs accessible
- [ ] Biometric enrollment functional

## 🚨 Troubleshooting

### Common DELI Issues:

#### 1. Connection Failed
```bash
# Check DELI device IP
ping [DELI_IP]

# Verify HTTP interface enabled on DELI
curl http://[DELI_IP]/control

# Check firewall/network settings
```

#### 2. API Key Authentication
```bash
# If DELI requires API key, generate one in BIOMIDDLEWARE
# Set it on DELI device using SetSecurityConfig
```

#### 3. Protocol Mismatch
```bash
# DELI uses identical protocol to ZKTeco
# If issues occur, verify DELI firmware version
# Update to latest DELI firmware supporting offline SDK
```

#### 4. Network Configuration
```bash
# Ensure DELI and BIOMIDDLEWARE on same network
# Check routing and firewall rules
# Verify DELI HTTP interface not disabled
```

## 📈 Performance Optimization

### DELI-Specific Optimizations:
- Use wired Ethernet connection for best performance
- Configure appropriate polling intervals
- Enable automatic attendance log uploading
- Set reasonable device timeouts

### Monitoring DELI Devices:
```javascript
// BIOMIDDLEWARE provides real-time monitoring:
// - Connection status
// - Response times  
// - Error rates
// - Usage statistics
```

## 📝 DELI Protocol Compliance

BIOMIDDLEWARE follows the exact DELI Offline SDK Protocol:

### Request Format (DELI Standard):
```json
{
  "mid": "message_id",
  "cmd": "command_name",
  "payload": { /* command-specific data */ }
}
```

### Response Format (DELI Standard):
```json
{
  "mid": "message_id", 
  "result": "Success|UserInfo|Error",
  "payload": { /* response data */ }
}
```

### Authentication (DELI Standard):
```
URL: http(s)://device_IP/control?api_key=API_key
Method: POST
Content-Type: application/json
```

## 🎯 Conclusion

**DELI biometric scanners work perfectly with BIOMIDDLEWARE** because:

1. ✅ **Identical Protocol**: DELI uses the exact same protocol as BIOMIDDLEWARE implements
2. ✅ **Same Commands**: All biometric operations supported
3. ✅ **Same Interface**: HTTP POST with JSON payloads
4. ✅ **Same Authentication**: API key via URL parameter
5. ✅ **Same Features**: Face, fingerprint, palm, card, attendance tracking

Simply add your DELI device IP address to BIOMIDDLEWARE and it will work immediately!

---

**Need Help?**
- Check BIOMIDDLEWARE logs for connection details
- Verify DELI device network settings
- Test basic HTTP connectivity first
- Contact support with DELI device model and firmware version
